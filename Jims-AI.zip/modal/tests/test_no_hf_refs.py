"""
test_no_hf_refs.py — CI guard: fail if any active source file references HF Space.

Task: 11.3
Requirements: 1.1, Property 1

Runs the same logic as scripts/check_no_hf_space_refs.py as a pytest test,
so it integrates into the standard test suite.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).parent.parent.parent  # c:\Users\ajibe\Jims-AI

BANNED_PATTERNS = [
    "jimstechai-jimsai-embedding-service.hf.space",
    ".hf.space",
    "JIMS_LOCAL_INFERENCE_URL",
    "JIMS_QWEN_SERVICE_URL",
    "JIMS_CAPABILITY_CLASSIFIER_URL",
    "JIMS_RENDER_AGENT_TOKEN",
    "HF_SPACE_REPO_ID",
    "_wake_hf_space",
]

EXCLUDE_DIRS = frozenset([
    ".git", "node_modules", "__pycache__", ".kiro", "_archived",
    ".kaggle_runs", ".cache", ".lambda-build", ".venv", "venv",
    "dist", "build", ".pytest_cache", "jims_ai.egg-info",
])

EXCLUDE_FILES = frozenset([
    "DEPLOYMENT_GUIDE.md",
    "hf_space_audit.md",
    "check_no_hf_space_refs.py",
    "test_no_hf_refs.py",       # this file itself references the patterns
    "requirements.md",
    "design.md",
    "tasks.md",                  # spec docs describe the migration
    "The_Prediction_Trap_Paper.md",
    "test_hf_render.py",         # legacy diagnostic kept for reference
    ".env",                      # live secrets file (gitignored)
    # Legacy prototype test files that reference the old HF Space integration
    # and will be updated separately as part of the prototype test suite refresh
    "test_multimodal_encoder.py",
    "test_qwen_bridge.py",
])

ALLOWED_EXTENSIONS = frozenset([
    ".py", ".ts", ".js", ".tsx", ".jsx",
    ".json", ".yaml", ".yml", ".toml",
    ".example",  # .env.example files are scanned but .env itself is excluded
])


def _should_scan(path: Path) -> bool:
    if path.name in EXCLUDE_FILES:
        return False
    if any(part in EXCLUDE_DIRS for part in path.parts):
        return False
    # Only scan .env.example and .env.production.example, not live .env
    if path.name.startswith(".env") and path.suffix == "":
        return False
    return path.suffix in ALLOWED_EXTENSIONS or path.name.endswith(".example")


def _collect_violations() -> list[str]:
    violations: list[str] = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if not _should_scan(path):
            continue
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        for pattern in BANNED_PATTERNS:
            if pattern in content:
                rel = str(path.relative_to(ROOT))
                violations.append(f"{rel}: '{pattern}'")
    return violations


def test_no_hf_space_references_in_source_files():
    """No active source file may reference retired HF Space URLs or env vars.

    Requirements: 1.1, 1.3, 1.4, 1.5, 1.6, 1.7, Property 1
    """
    violations = _collect_violations()
    if violations:
        msg = "\n".join(f"  {v}" for v in violations)
        pytest.fail(
            f"Found {len(violations)} HF Space reference(s) in active files:\n{msg}\n"
            "Remove all HF Space references before completing the migration."
        )


def test_env_example_has_modal_service_urls():
    """Verify .env.example contains the five Modal service URL placeholders."""
    env_example = ROOT / ".env.example"
    assert env_example.exists(), ".env.example not found"
    content = env_example.read_text(encoding="utf-8")
    required_vars = [
        "JIMS_EMBEDDING_SERVICE_URL",
        "JIMS_CLASSIFICATION_SERVICE_URL",
        "JIMS_INTENT_SERVICE_URL",
        "JIMS_RENDERER_SERVICE_URL",
        "JIMS_REASONING_SERVICE_URL",
        "JIMS_MODAL_API_KEY",
        "JIMS_EMBEDDING_TIMEOUT",
        "JIMS_GENERATION_TIMEOUT",
        "JIMS_REASONING_CONFIDENCE_THRESHOLD",
        "JIMS_REASONING_DEPTH_THRESHOLD",
    ]
    missing = [v for v in required_vars if v not in content]
    assert not missing, f".env.example is missing: {missing}"


def test_env_example_no_hf_space_url():
    """.env.example must not contain any HF Space URLs."""
    env_example = ROOT / ".env.example"
    content = env_example.read_text(encoding="utf-8")
    assert "hf.space" not in content, ".env.example still contains hf.space URLs"


def test_hf_space_infra_archived():
    """HF Space infrastructure directory must be archived, not active."""
    active_hf_dir = ROOT / "infrastructure" / "huggingface-space"
    archived_dir = ROOT / "infrastructure" / "_archived" / "huggingface-space"
    assert not active_hf_dir.exists(), (
        f"HF Space infra still in active location: {active_hf_dir}"
    )
    assert archived_dir.exists(), (
        f"HF Space infra not found in archived location: {archived_dir}"
    )


def test_deploy_hf_space_script_removed():
    """scripts/deploy_hf_space.py must have been removed."""
    deploy_script = ROOT / "scripts" / "deploy_hf_space.py"
    assert not deploy_script.exists(), (
        f"deploy_hf_space.py still exists at {deploy_script} — should be removed"
    )
