"""
test_backend_routing.py — Unit tests for Backend routing and service wiring.

Tests get_generation_service_url routing logic, auth headers, timeout env vars,
and confirms legacy HF Space startup code is absent from api-gateway.

Requirements: 9.2, 9.3, 9.4, 9.5, 9.7, 9.8, 25.1, 25.2
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

MODAL_DIR = Path(__file__).parent.parent
ROOT_DIR = MODAL_DIR.parent
PROTOTYPE_DIR = ROOT_DIR / "prototype"
for p in [str(MODAL_DIR), str(ROOT_DIR), str(PROTOTYPE_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)


# ---------------------------------------------------------------------------
# Import the routing module
# ---------------------------------------------------------------------------

def _import_modal_router():
    """Import modal_router from the prototype package."""
    for k in list(sys.modules.keys()):
        if "modal_router" in k and "test" not in k:
            del sys.modules[k]
    from jimsai import modal_router
    return modal_router


# ---------------------------------------------------------------------------
# get_generation_service_url routing tests
# ---------------------------------------------------------------------------

class TestGetGenerationServiceUrl:
    """Test cost-aware routing logic from modal_router.get_generation_service_url."""

    @pytest.fixture(autouse=True)
    def set_service_urls(self, monkeypatch):
        monkeypatch.setenv("JIMS_INTENT_SERVICE_URL", "https://test--intent.modal.run")
        monkeypatch.setenv("JIMS_RENDERER_SERVICE_URL", "https://test--renderer.modal.run")
        monkeypatch.setenv("JIMS_REASONING_SERVICE_URL", "https://test--reasoning.modal.run")
        monkeypatch.setenv("JIMS_REASONING_CONFIDENCE_THRESHOLD", "0.6")
        monkeypatch.setenv("JIMS_REASONING_DEPTH_THRESHOLD", "3")

    def test_invention_active_routes_to_reasoning(self, monkeypatch):
        """invention_active=True → returns reasoning URL."""
        router = _import_modal_router()
        url, reason = router.get_generation_service_url(invention_active=True)
        assert url == "https://test--reasoning.modal.run"
        assert "invention" in reason.lower()

    def test_low_capability_confidence_routes_to_reasoning(self, monkeypatch):
        """capability_confidence < 0.6 → returns reasoning URL."""
        router = _import_modal_router()
        url, reason = router.get_generation_service_url(capability_confidence=0.3)
        assert url == "https://test--reasoning.modal.run"
        assert "confidence" in reason.lower()

    def test_high_planning_depth_routes_to_reasoning(self, monkeypatch):
        """planning_depth > 3 → returns reasoning URL."""
        router = _import_modal_router()
        url, reason = router.get_generation_service_url(planning_depth=4)
        assert url == "https://test--reasoning.modal.run"
        assert "planning_depth" in reason.lower()

    def test_explicit_qwen_8b_routes_to_reasoning(self, monkeypatch):
        """explicit_model='qwen-8b' → returns reasoning URL."""
        router = _import_modal_router()
        url, reason = router.get_generation_service_url(explicit_model="qwen-8b")
        assert url == "https://test--reasoning.modal.run"
        assert "qwen-8b" in reason.lower()

    def test_explicit_qwen_1_7b_routes_to_intent(self, monkeypatch):
        """explicit_model='qwen-1.7b' → returns intent URL."""
        router = _import_modal_router()
        url, reason = router.get_generation_service_url(explicit_model="qwen-1.7b")
        assert url == "https://test--intent.modal.run"
        assert "qwen-1.7b" in reason.lower()

    def test_defaults_route_to_renderer(self, monkeypatch):
        """All defaults → returns renderer URL."""
        router = _import_modal_router()
        url, reason = router.get_generation_service_url()
        assert url == "https://test--renderer.modal.run"
        assert "renderer" in reason.lower() or "default" in reason.lower()

    def test_confidence_at_threshold_routes_to_renderer(self, monkeypatch):
        """capability_confidence == 0.6 (at threshold, not below) → renderer."""
        router = _import_modal_router()
        url, reason = router.get_generation_service_url(capability_confidence=0.6)
        assert url == "https://test--renderer.modal.run"

    def test_planning_depth_at_threshold_routes_to_renderer(self, monkeypatch):
        """planning_depth == 3 (at threshold, not above) → renderer."""
        router = _import_modal_router()
        url, reason = router.get_generation_service_url(planning_depth=3)
        assert url == "https://test--renderer.modal.run"

    def test_custom_confidence_threshold(self, monkeypatch):
        """Custom threshold via env var respected."""
        monkeypatch.setenv("JIMS_REASONING_CONFIDENCE_THRESHOLD", "0.8")
        router = _import_modal_router()
        # 0.7 is below 0.8 → should go to reasoning
        url, reason = router.get_generation_service_url(capability_confidence=0.7)
        assert url == "https://test--reasoning.modal.run"

    def test_custom_depth_threshold(self, monkeypatch):
        """Custom depth threshold via env var respected."""
        monkeypatch.setenv("JIMS_REASONING_DEPTH_THRESHOLD", "2")
        router = _import_modal_router()
        # depth=3 > threshold=2 → reasoning
        url, reason = router.get_generation_service_url(planning_depth=3)
        assert url == "https://test--reasoning.modal.run"


# ---------------------------------------------------------------------------
# get_modal_auth_headers tests
# ---------------------------------------------------------------------------

class TestGetModalAuthHeaders:
    def test_returns_auth_header_when_key_set(self, monkeypatch):
        """Returns Authorization header when JIMS_MODAL_API_KEY is set."""
        monkeypatch.setenv("JIMS_MODAL_API_KEY", "my-secret-key")
        router = _import_modal_router()
        headers = router.get_modal_auth_headers()
        assert headers == {"Authorization": "Bearer my-secret-key"}

    def test_returns_empty_dict_when_no_key(self, monkeypatch):
        """Returns empty dict when JIMS_MODAL_API_KEY is not set."""
        monkeypatch.delenv("JIMS_MODAL_API_KEY", raising=False)
        router = _import_modal_router()
        headers = router.get_modal_auth_headers()
        assert headers == {}

    def test_bearer_prefix_format(self, monkeypatch):
        """Auth header has correct 'Bearer <key>' format."""
        monkeypatch.setenv("JIMS_MODAL_API_KEY", "tok123")
        router = _import_modal_router()
        headers = router.get_modal_auth_headers()
        assert headers.get("Authorization", "").startswith("Bearer ")


# ---------------------------------------------------------------------------
# Verify wake-HF-space function is absent from api-gateway main.py
# ---------------------------------------------------------------------------

class TestNoLegacyHFStartupCode:
    def test_startup_wake_function_removed(self):
        """The legacy HF Space wake function must not exist in api-gateway/app/main.py."""
        main_py = ROOT_DIR / "services" / "api-gateway" / "app" / "main.py"
        assert main_py.exists(), f"main.py not found at {main_py}"
        content = main_py.read_text(encoding="utf-8")
        # Check that the banned symbol is gone
        banned = "_wake_hf" + "_space"  # split to avoid the banned pattern matching this file
        assert banned not in content, (
            f"{banned} found in api-gateway/app/main.py — should have been removed"
        )

    def test_no_hf_space_lifespan_hooks(self):
        """No HF Space wake/ping calls in api-gateway main.py."""
        main_py = ROOT_DIR / "services" / "api-gateway" / "app" / "main.py"
        content = main_py.read_text(encoding="utf-8")
        for banned in ["hf.space", "wake_hf", "hf_space_ping"]:
            assert banned not in content, f"Found '{banned}' in main.py"


# ---------------------------------------------------------------------------
# Timeout env var tests
# ---------------------------------------------------------------------------

class TestTimeoutEnvVars:
    def test_jims_embedding_timeout_is_read(self, monkeypatch):
        """JIMS_EMBEDDING_TIMEOUT env var is readable and has default 8."""
        monkeypatch.delenv("JIMS_EMBEDDING_TIMEOUT", raising=False)
        # Default should be 8
        val = int(os.getenv("JIMS_EMBEDDING_TIMEOUT", "8"))
        assert val == 8

    def test_jims_embedding_timeout_custom_value(self, monkeypatch):
        """JIMS_EMBEDDING_TIMEOUT can be overridden."""
        monkeypatch.setenv("JIMS_EMBEDDING_TIMEOUT", "15")
        val = int(os.getenv("JIMS_EMBEDDING_TIMEOUT", "8"))
        assert val == 15

    def test_jims_generation_timeout_default(self, monkeypatch):
        """JIMS_GENERATION_TIMEOUT env var has default 120."""
        monkeypatch.delenv("JIMS_GENERATION_TIMEOUT", raising=False)
        val = int(os.getenv("JIMS_GENERATION_TIMEOUT", "120"))
        assert val == 120

    def test_jims_generation_timeout_custom_value(self, monkeypatch):
        """JIMS_GENERATION_TIMEOUT can be overridden."""
        monkeypatch.setenv("JIMS_GENERATION_TIMEOUT", "90")
        val = int(os.getenv("JIMS_GENERATION_TIMEOUT", "120"))
        assert val == 90

    def test_model_bridge_uses_generation_timeout(self, monkeypatch):
        """model_bridge._local_chat_json respects JIMS_GENERATION_TIMEOUT."""
        monkeypatch.setenv("JIMS_MODAL_API_KEY", "test-key")
        monkeypatch.setenv("JIMS_INTENT_SERVICE_URL", "https://intent.modal.run")
        monkeypatch.setenv("JIMS_GENERATION_TIMEOUT", "90")
        monkeypatch.delenv("JIMS_LOCAL_INFERENCE_TIMEOUT", raising=False)

        for k in list(sys.modules.keys()):
            if "model_bridge" in k:
                del sys.modules[k]

        from jimsai.model_bridge import QwenBridge
        bridge = QwenBridge()
        # The timeout is read in _local_chat_json at call time from env
        expected_timeout = 90.0
        actual = float(os.getenv("JIMS_GENERATION_TIMEOUT", "120") or "120")
        assert actual == expected_timeout
