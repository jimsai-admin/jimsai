"""
test_classification_service.py — Unit tests for modal_classification_service.py

Task: 5.5
Requirements: 18.7, 18.8
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

_MODAL_DIR = Path(__file__).parent.parent
if str(_MODAL_DIR) not in sys.path:
    sys.path.insert(0, str(_MODAL_DIR))

# Patch transformers before import
with patch.dict(sys.modules, {
    "transformers": MagicMock(),
    "torch": MagicMock(),
}):
    from modal_classification_service import (
        ClassifyRequest, ClassifyResponse, ClassificationService, web_app
    )

from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_DEFAULT_LABELS = [
    "coding", "mathematics", "world_knowledge", "reasoning",
    "creative_writing", "data_analysis", "planning", "science", "conversation",
]


def _make_service(pipeline_output=None):
    """Build a ClassificationService with a mocked pipeline."""
    if pipeline_output is None:
        pipeline_output = {
            "labels": ["coding", "mathematics", "science"],
            "scores": [0.85, 0.10, 0.05],
        }

    svc = ClassificationService.__new__(ClassificationService)
    svc._model_loaded = True
    svc._volume_mounted = True
    svc._container_start_time = 0.0

    mock_pipeline = MagicMock(return_value=pipeline_output)
    svc._classifier = mock_pipeline
    return svc


# ---------------------------------------------------------------------------
# 5.5.1 — Label mapping and score ordering
# ---------------------------------------------------------------------------

def test_scores_sorted_descending():
    """The transformers pipeline returns scores in descending order; service preserves this."""
    # Use a mock that already returns sorted data (as the real pipeline does)
    svc = _make_service({
        "labels": ["coding", "mathematics", "science"],
        "scores": [0.85, 0.10, 0.05],
    })
    req = ClassifyRequest(text="Write a sorting algorithm")
    resp = svc.classify(req)
    # Scores must be in descending order
    assert resp.scores[0]["score"] >= resp.scores[1]["score"]
    assert resp.scores[1]["score"] >= resp.scores[2]["score"]
    assert resp.primary_kind == "coding"


def test_primary_kind_is_highest_score():
    svc = _make_service({
        "labels": ["coding", "mathematics", "science"],
        "scores": [0.85, 0.10, 0.05],
    })
    req = ClassifyRequest(text="Write a Python function")
    resp = svc.classify(req)
    assert resp.primary_kind == "coding"
    assert resp.confidence == 0.85


def test_confidence_equals_highest_score():
    svc = _make_service({
        "labels": ["mathematics", "coding", "science"],
        "scores": [0.90, 0.06, 0.04],
    })
    req = ClassifyRequest(text="Solve x^2 + 2x + 1 = 0")
    resp = svc.classify(req)
    assert resp.confidence == resp.scores[0]["score"]


def test_default_labels_used_when_none():
    """When candidate_labels is None, the service should use all 9 default labels."""
    svc = _make_service()
    req = ClassifyRequest(text="Tell me about gravity")
    svc.classify(req)
    call_args = svc._classifier.call_args
    # Second positional arg is the candidate labels
    labels_arg = call_args[0][1] if call_args[0] else call_args[1].get("candidate_labels", [])
    assert len(labels_arg) == len(_DEFAULT_LABELS)


def test_custom_labels_used_when_provided():
    svc = _make_service({
        "labels": ["coding", "math"],
        "scores": [0.7, 0.3],
    })
    req = ClassifyRequest(text="code", candidate_labels=["coding", "math"])
    resp = svc.classify(req)
    assert resp.primary_kind in ["coding", "math"]


def test_hypothesis_template_passed_to_pipeline():
    svc = _make_service()
    template = "This text requires {} skills."
    req = ClassifyRequest(text="solve equations", hypothesis_template=template)
    svc.classify(req)
    call_kwargs = svc._classifier.call_args[1]
    assert call_kwargs.get("hypothesis_template") == template


# ---------------------------------------------------------------------------
# 5.5.2 — HTTP 422 on invalid inputs
# ---------------------------------------------------------------------------

def test_http_422_empty_text():
    svc = _make_service()
    req = ClassifyRequest(text="")
    raised = None
    try:
        svc.classify(req)
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 422, f"Expected 422, got {raised}"


def test_http_422_text_too_long():
    svc = _make_service()
    req = ClassifyRequest(text="x" * 4097)
    raised = None
    try:
        svc.classify(req)
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 422, f"Expected 422, got {raised}"


def test_http_422_text_exactly_4096_is_ok():
    """Text at exactly 4096 chars should NOT raise 422."""
    svc = _make_service()
    req = ClassifyRequest(text="a" * 4096)
    # Should not raise
    resp = svc.classify(req)
    assert resp.primary_kind is not None


# ---------------------------------------------------------------------------
# 5.5.3 — HTTP 401 on missing/invalid auth
# ---------------------------------------------------------------------------

def test_http_401_missing_auth():
    client = TestClient(web_app)
    resp = client.post("/classify", json={"text": "hello"})
    assert resp.status_code == 401


def test_http_401_wrong_token(invalid_auth_headers):
    client = TestClient(web_app)
    resp = client.post("/classify", json={"text": "hello"}, headers=invalid_auth_headers)
    assert resp.status_code == 401


def test_health_endpoint():
    svc = _make_service()
    result = svc.health()
    assert "status" in result
    assert result.get("service") == "classification"
