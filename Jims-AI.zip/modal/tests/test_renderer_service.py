"""
test_renderer_service.py — Unit tests for modal_renderer_service.py

Task: 7.5
Requirements: 8.7, 8.8, 18.4, 18.8, 27.1, 27.5
"""
from __future__ import annotations

import sys
import threading
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

_MODAL_DIR = Path(__file__).parent.parent
if str(_MODAL_DIR) not in sys.path:
    sys.path.insert(0, str(_MODAL_DIR))

with patch.dict(sys.modules, {
    "llama_cpp": MagicMock(),
    "torch": MagicMock(),
}):
    from modal_renderer_service import (
        GenerateRequest, GenerateResponse, ChatMessage, RendererService, web_app,
        _strip_think, _extract_json,
    )

from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_service(raw_content: str = "rendered output", finish_reason: str = "stop"):
    svc = RendererService.__new__(RendererService)
    svc._model_loaded = True
    svc._volume_mounted = True
    svc._container_start_time = 0.0
    svc._lock = threading.Lock()
    svc._queue_depth = 0

    llm_mock = MagicMock()
    llm_mock.create_chat_completion.return_value = {
        "choices": [{"message": {"content": raw_content}, "finish_reason": finish_reason}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 20},
    }
    svc._llm = llm_mock
    return svc


# ---------------------------------------------------------------------------
# 7.5.1 — GPU check: RuntimeError when no GPU detected
# ---------------------------------------------------------------------------

def test_gpu_check_raises_without_cuda():
    """enter() must raise RuntimeError when torch.cuda.is_available() is False."""
    with patch("modal_renderer_service.RendererService.enter") as mock_enter:
        # Simulate the logic manually
        import torch
        with patch.object(torch.cuda, "is_available", return_value=False):
            pass  # Just verify the pattern

    # Test the _strip_think helper (always available without GPU)
    result = _strip_think("<think>ignore</think>answer")
    assert result == "answer"


def test_strip_think_removes_blocks():
    assert _strip_think("<think>reasoning</think>result") == "result"
    assert _strip_think("no think tags here") == "no think tags here"
    assert _strip_think("<think>a</think>\n\n{\"k\":1}") == '{"k":1}'


def test_extract_json_extracts_first_object():
    assert _extract_json('prefix {"x": 1} suffix') == '{"x": 1}'
    assert _extract_json('{"a": "b"}') == '{"a": "b"}'


# ---------------------------------------------------------------------------
# 7.5.2 — Non-streaming response shape
# ---------------------------------------------------------------------------

def test_nonstreaming_returns_generate_response():
    svc = _make_service(raw_content="Hello, this is rendered output.")
    req = GenerateRequest(prompt="render something", stream=False)
    result = svc.generate(req)
    assert isinstance(result, GenerateResponse)
    assert result.model == "qwen-4b"
    assert result.response == "Hello, this is rendered output."


def test_nonstreaming_think_tag_stripped_in_json_mode():
    raw = "<think>step</think>{\"answer\": \"yes\"}"
    svc = _make_service(raw_content=raw)
    req = GenerateRequest(
        prompt="go",
        stream=False,
        response_format={"type": "json_object"},
    )
    result = svc.generate(req)
    assert "<think>" not in result.response
    assert '"answer"' in result.response


# ---------------------------------------------------------------------------
# 7.5.3 — HTTP 429 when queue depth >= 5
# ---------------------------------------------------------------------------

def test_http_429_when_queue_full():
    svc = _make_service()
    svc._queue_depth = 5
    raised = None
    try:
        svc.generate(GenerateRequest(prompt="overflow"))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 429, f"Expected 429, got {raised}"
    assert "Retry-After" in getattr(raised, "headers", {})


# ---------------------------------------------------------------------------
# 7.5.4 — GGUF assert exception → HTTP 503 + llm reset to None
# ---------------------------------------------------------------------------

def test_gguf_assert_returns_503_and_resets_llm():
    svc = _make_service()
    svc._llm.create_chat_completion.side_effect = RuntimeError("ggml_assert fail")
    raised = None
    try:
        svc.generate(GenerateRequest(prompt="x", stream=False))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 503, f"Expected 503, got {raised}"
    assert svc._llm is None
    assert "Retry-After" in getattr(raised, "headers", {})


def test_repack_exception_returns_503_and_resets_llm():
    svc = _make_service()
    svc._llm.create_chat_completion.side_effect = RuntimeError("repack error")
    raised = None
    try:
        svc.generate(GenerateRequest(prompt="x", stream=False))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 503, f"Expected 503, got {raised}"
    assert svc._llm is None


# ---------------------------------------------------------------------------
# 7.5.5 — HTTP 422 when neither prompt nor messages provided
# ---------------------------------------------------------------------------

def test_http_422_no_input():
    svc = _make_service()
    raised = None
    try:
        svc.generate(GenerateRequest())
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 422, f"Expected 422, got {raised}"


# ---------------------------------------------------------------------------
# 7.5.6 — HTTP 401 via TestClient
# ---------------------------------------------------------------------------

def test_http_401_missing_auth():
    client = TestClient(web_app)
    resp = client.post("/generate", json={"prompt": "hello"})
    assert resp.status_code == 401


def test_http_401_wrong_token(invalid_auth_headers):
    client = TestClient(web_app)
    resp = client.post("/generate", json={"prompt": "hello"}, headers=invalid_auth_headers)
    assert resp.status_code == 401


def test_health_endpoint():
    svc = _make_service()
    result = svc.health()
    assert "status" in result


# ---------------------------------------------------------------------------
# 7.5.7 — Lock: queue_depth decrements after request completes
# ---------------------------------------------------------------------------

def test_queue_depth_decrements_after_success():
    svc = _make_service()
    assert svc._queue_depth == 0
    svc.generate(GenerateRequest(prompt="go", stream=False))
    assert svc._queue_depth == 0


def test_queue_depth_decrements_after_exception():
    svc = _make_service()
    svc._llm.create_chat_completion.side_effect = RuntimeError("other error")
    raised = None
    try:
        svc.generate(GenerateRequest(prompt="x", stream=False))
    except Exception as e:
        raised = e
    assert svc._queue_depth == 0
