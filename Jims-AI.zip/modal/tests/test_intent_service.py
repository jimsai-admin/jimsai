"""
test_intent_service.py — Unit tests for modal_intent_service.py

Task: 6.5
Requirements: 18.3, 18.8
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

_MODAL_DIR = Path(__file__).parent.parent
if str(_MODAL_DIR) not in sys.path:
    sys.path.insert(0, str(_MODAL_DIR))

with patch.dict(sys.modules, {
    "llama_cpp": MagicMock(),
}):
    from modal_intent_service import (
        GenerateRequest, GenerateResponse, ChatMessage, IntentService, web_app
    )

from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_service(raw_content: str = '{"answer": "ok"}', finish_reason: str = "stop"):
    """Build an IntentService with a mocked Llama instance."""
    svc = IntentService.__new__(IntentService)
    svc._model_loaded = True
    svc._volume_mounted = True
    svc._container_start_time = 0.0
    svc._lock = None

    llm_mock = MagicMock()
    llm_mock.create_chat_completion.return_value = {
        "choices": [{"message": {"content": raw_content}, "finish_reason": finish_reason}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 20},
    }
    svc._llm = llm_mock
    return svc


# ---------------------------------------------------------------------------
# 6.5.1 — HTTP 422 when neither prompt nor messages is provided
# ---------------------------------------------------------------------------

def test_http_422_no_prompt_or_messages():
    svc = _make_service()
    raised = None
    try:
        svc.generate(GenerateRequest())
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 422, f"Expected 422, got {raised}"


def test_prompt_provided_succeeds():
    svc = _make_service(raw_content="Hello world")
    req = GenerateRequest(prompt="Say hi")
    resp = svc.generate(req)
    assert resp.response == "Hello world"
    assert resp.model == "qwen-1.7b"


def test_messages_provided_succeeds():
    svc = _make_service(raw_content="I am fine")
    req = GenerateRequest(messages=[ChatMessage(role="user", content="How are you?")])
    resp = svc.generate(req)
    assert resp.model == "qwen-1.7b"


# ---------------------------------------------------------------------------
# 6.5.2 — <think> tag stripping in JSON mode
# ---------------------------------------------------------------------------

def test_think_tag_stripped_in_json_mode():
    raw = "<think>inner reasoning</think>\n{\"result\": 42}"
    svc = _make_service(raw_content=raw)
    req = GenerateRequest(
        prompt="compute",
        response_format={"type": "json_object"},
    )
    resp = svc.generate(req)
    assert "<think>" not in resp.response
    assert "42" in resp.response


def test_think_tag_preserved_outside_json_mode():
    raw = "<think>reasoning</think> The answer is 7."
    svc = _make_service(raw_content=raw)
    req = GenerateRequest(prompt="compute", response_format=None)
    resp = svc.generate(req)
    # Without json_object mode, content is returned as-is
    assert resp.response == raw


def test_nested_think_tags_stripped():
    raw = "<think>step1<think>step2</think></think>{\"x\": 1}"
    svc = _make_service(raw_content=raw)
    req = GenerateRequest(prompt="go", response_format={"type": "json_object"})
    resp = svc.generate(req)
    assert "<think>" not in resp.response


# ---------------------------------------------------------------------------
# 6.5.3 — GGUF error resets llm instance
# ---------------------------------------------------------------------------

def test_gguf_assert_resets_llm():
    svc = _make_service()
    svc._llm.create_chat_completion.side_effect = RuntimeError("ggml_assert failed!")
    raised = None
    try:
        svc.generate(GenerateRequest(prompt="x"))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 503, f"Expected 503, got {raised}"
    assert svc._llm is None


# ---------------------------------------------------------------------------
# 6.5.4 — Default max_tokens and model
# ---------------------------------------------------------------------------

def test_default_model_is_qwen_17b():
    svc = _make_service()
    req = GenerateRequest(prompt="hello")
    resp = svc.generate(req)
    assert resp.model == "qwen-1.7b"


def test_finish_reason_returned():
    svc = _make_service(raw_content="ok", finish_reason="length")
    req = GenerateRequest(prompt="x")
    resp = svc.generate(req)
    assert resp.finish_reason == "length"


# ---------------------------------------------------------------------------
# 6.5.5 — HTTP 401 via TestClient
# ---------------------------------------------------------------------------

def test_http_401_missing_auth():
    client = TestClient(web_app)
    resp = client.post("/generate", json={"prompt": "hello"})
    assert resp.status_code == 401


def test_http_401_wrong_token(invalid_auth_headers):
    client = TestClient(web_app)
    resp = client.post("/generate", json={"prompt": "hello"}, headers=invalid_auth_headers)
    assert resp.status_code == 401


def test_health_endpoint():
    svc = _make_service()
    result = svc.health()
    assert "status" in result
    assert result.get("service") == "intent"
