"""
test_integration_classification.py — Integration test: Backend → Classification_Service

Task: 13.2
Requirements: 20.2, 20.5

Tests that capability_router calls Classification Service with proper Authorization
headers when zero-shot classification is enabled.
"""
from __future__ import annotations

import sys
import os
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest

MODAL_DIR = Path(__file__).parent.parent
ROOT_DIR = MODAL_DIR.parent
PROTOTYPE_DIR = ROOT_DIR / "prototype"
for p in [str(MODAL_DIR), str(ROOT_DIR), str(PROTOTYPE_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

pytestmark = pytest.mark.integration


class TestBackendToClassificationService:
    """Integration tests: Backend → Classification_Service call pattern."""

    @pytest.fixture(autouse=True)
    def setup_env(self, monkeypatch):
        monkeypatch.setenv("JIMS_CLASSIFICATION_SERVICE_URL", "https://test--classification.modal.run")
        monkeypatch.setenv("JIMS_MODAL_API_KEY", "integration-test-key")
        monkeypatch.setenv("JIMS_ENABLE_ZERO_SHOT_CAPABILITY_ROUTER", "true")

    def test_classification_url_is_modal_not_hf(self, monkeypatch):
        """JIMS_CLASSIFICATION_SERVICE_URL must point to Modal, not HF Space."""
        url = os.getenv("JIMS_CLASSIFICATION_SERVICE_URL", "")
        assert "hf.space" not in url
        assert url != ""

    def test_capability_router_calls_classification_with_auth(self, monkeypatch):
        """capability_router must inject Authorization header on /classify calls."""
        captured: list[dict] = []

        import httpx

        class _MockResponse:
            status_code = 200
            def json(self):
                return {
                    "primary_kind": "coding",
                    "confidence": 0.88,
                    "secondary_kinds": ["mathematics"],
                    "scores": [
                        {"kind": "coding", "score": 0.88},
                        {"kind": "mathematics", "score": 0.07},
                    ],
                    "model": "mDeBERTa-v3-base-mnli-xnli",
                }
            def raise_for_status(self): pass

        async def _mock_post(url, *, headers=None, json=None, timeout=None, **kwargs):
            captured.append({"url": url, "headers": dict(headers or {})})
            return _MockResponse()

        # Patch httpx.AsyncClient.post for capability_router
        monkeypatch.setenv("JIMS_MODAL_API_KEY", "integration-test-key")

        import asyncio
        from jimsai.capability_router import CapabilityRouter

        router = CapabilityRouter()

        if hasattr(router, "classifier_url") and router.classifier_url:
            with patch("httpx.AsyncClient") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__aenter__ = AsyncMock(return_value=mock_client)
                mock_client.__aexit__ = AsyncMock(return_value=False)
                mock_client.post = AsyncMock(return_value=_MockResponse())
                mock_client_cls.return_value = mock_client

                try:
                    result = asyncio.run(router._zero_shot_classifier_scores("write a python sort"))
                except Exception:
                    pass

                # Check auth header on any call made
                for call in mock_client.post.call_args_list:
                    headers = call.kwargs.get("headers", {}) or {}
                    if "Authorization" in headers:
                        assert headers["Authorization"].startswith("Bearer ")

    def test_classify_endpoint_requires_auth(self):
        """POST /classify without auth → 401."""
        with patch.dict(sys.modules, {
            "transformers": MagicMock(),
            "torch": MagicMock(),
        }):
            from modal_classification_service import web_app
        from fastapi.testclient import TestClient
        client = TestClient(web_app)
        resp = client.post("/classify", json={"text": "hello world"})
        assert resp.status_code == 401

    def test_classify_returns_sorted_scores(self, monkeypatch):
        """Classification response has scores sorted descending by score."""
        with patch.dict(sys.modules, {
            "transformers": MagicMock(),
            "torch": MagicMock(),
        }):
            from modal_classification_service import ClassifyRequest, ClassifyResponse, ClassificationService

        pipeline_output = {
            "labels": ["coding", "mathematics", "science"],
            "scores": [0.82, 0.12, 0.06],
        }
        svc = ClassificationService.__new__(ClassificationService)
        svc._model_loaded = True
        svc._volume_mounted = True
        svc._container_start_time = 0.0
        svc._classifier = MagicMock(return_value=pipeline_output)

        req = ClassifyRequest(text="write a bubble sort algorithm")
        resp = svc.classify(req)

        # Scores must be sorted descending
        scores = [s["score"] for s in resp.scores]
        assert scores == sorted(scores, reverse=True)
        assert resp.primary_kind == "coding"
        assert resp.confidence == 0.82
