"""
test_integration_pipeline.py — Integration test: Full VCO pipeline

Task: 13.3
Requirements: 20.3, 20.5

Tests the full end-to-end routing: query → Backend → Embedding → Classification
→ Renderer (or Reasoning based on routing) → response, using mocked HTTP clients.
"""
from __future__ import annotations

import sys
import os
import json
from pathlib import Path
from unittest.mock import patch, MagicMock, AsyncMock

import pytest

MODAL_DIR = Path(__file__).parent.parent
ROOT_DIR = MODAL_DIR.parent
PROTOTYPE_DIR = ROOT_DIR / "prototype"
for p in [str(MODAL_DIR), str(ROOT_DIR), str(PROTOTYPE_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

pytestmark = pytest.mark.integration


class TestVCOPipeline:
    """Full VCO pipeline integration: mocked AI services."""

    @pytest.fixture(autouse=True)
    def setup_env(self, monkeypatch):
        monkeypatch.setenv("JIMS_EMBEDDING_SERVICE_URL", "https://test--embedding.modal.run")
        monkeypatch.setenv("JIMS_CLASSIFICATION_SERVICE_URL", "https://test--classification.modal.run")
        monkeypatch.setenv("JIMS_INTENT_SERVICE_URL", "https://test--intent.modal.run")
        monkeypatch.setenv("JIMS_RENDERER_SERVICE_URL", "https://test--renderer.modal.run")
        monkeypatch.setenv("JIMS_REASONING_SERVICE_URL", "https://test--reasoning.modal.run")
        monkeypatch.setenv("JIMS_MODAL_API_KEY", "pipeline-test-key")
        monkeypatch.setenv("JIMS_REASONING_CONFIDENCE_THRESHOLD", "0.6")
        monkeypatch.setenv("JIMS_REASONING_DEPTH_THRESHOLD", "3")

    def test_routing_logic_selects_renderer_by_default(self):
        """Default query routes to Renderer_Service (T2)."""
        from jimsai.modal_router import get_generation_service_url
        url, reason = get_generation_service_url(
            capability_confidence=0.9,
            planning_depth=1,
            invention_active=False,
        )
        assert "renderer" in url or url == os.getenv("JIMS_RENDERER_SERVICE_URL")

    def test_routing_selects_reasoning_for_invention(self):
        """Invention engine active → routes to Reasoning_Service."""
        from jimsai.modal_router import get_generation_service_url
        url, reason = get_generation_service_url(
            invention_active=True,
            capability_confidence=0.9,
        )
        assert "reasoning" in url or url == os.getenv("JIMS_REASONING_SERVICE_URL")

    def test_routing_selects_reasoning_for_low_confidence(self):
        """Low capability confidence → routes to Reasoning_Service."""
        from jimsai.modal_router import get_generation_service_url
        url, reason = get_generation_service_url(capability_confidence=0.4)
        assert "reasoning" in url or url == os.getenv("JIMS_REASONING_SERVICE_URL")

    def test_model_bridge_t1_uses_intent_url(self, monkeypatch):
        """QwenBridge uses JIMS_INTENT_SERVICE_URL for T1 (qwen-1.7b) calls."""
        monkeypatch.setenv("JIMS_LLM_PROVIDER", "local")
        monkeypatch.setenv("JIMS_ENABLE_LOCAL_QWEN", "true")

        for k in list(sys.modules.keys()):
            if "model_bridge" in k:
                del sys.modules[k]

        from jimsai.model_bridge import QwenBridge
        bridge = QwenBridge()
        expected_url = os.getenv("JIMS_INTENT_SERVICE_URL", "")
        assert bridge.local_url == expected_url.rstrip("/") or expected_url in bridge.local_url

    def test_model_bridge_t2_uses_renderer_url(self, monkeypatch):
        """QwenBridge uses JIMS_RENDERER_SERVICE_URL for T2 (render) calls."""
        monkeypatch.setenv("JIMS_LLM_PROVIDER", "local")
        monkeypatch.setenv("JIMS_ENABLE_LOCAL_QWEN", "true")

        for k in list(sys.modules.keys()):
            if "model_bridge" in k:
                del sys.modules[k]

        from jimsai.model_bridge import QwenBridge
        bridge = QwenBridge()
        expected = os.getenv("JIMS_RENDERER_SERVICE_URL", "")
        assert bridge.render_url == expected.rstrip("/") or expected in bridge.render_url

    def test_modal_api_key_used_for_auth(self, monkeypatch):
        """JIMS_MODAL_API_KEY is used as the Bearer token in all outbound calls."""
        monkeypatch.setenv("JIMS_LLM_PROVIDER", "local")
        monkeypatch.setenv("JIMS_ENABLE_LOCAL_QWEN", "true")
        monkeypatch.setenv("JIMS_MODAL_API_KEY", "pipeline-test-key")
        # Ensure no legacy keys override it
        monkeypatch.delenv("JIMS_LOCAL_INFERENCE_API_KEY", raising=False)

        for k in list(sys.modules.keys()):
            if "model_bridge" in k:
                del sys.modules[k]

        from jimsai.model_bridge import QwenBridge
        bridge = QwenBridge()
        assert bridge.local_api_key == "pipeline-test-key"


class TestGenerateResponseShape:
    """Verify generate response shape matches pre-migration contract."""

    def test_generate_response_has_required_fields(self):
        """GenerateResponse must have response, model, usage, finish_reason."""
        with patch.dict(sys.modules, {
            "llama_cpp": MagicMock(),
            "torch": MagicMock(),
        }):
            from modal_intent_service import GenerateResponse
        # Verify Pydantic model has required fields
        import inspect
        fields = GenerateResponse.model_fields
        for required_field in ["response", "model", "usage", "finish_reason"]:
            assert required_field in fields, f"GenerateResponse missing field: {required_field}"

    def test_embed_response_has_required_fields(self):
        """EmbedResponse must have vectors, model, dimension, fallback."""
        with patch.dict(sys.modules, {
            "sentence_transformers": MagicMock(),
            "transformers": MagicMock(),
            "torch": MagicMock(),
            "einops": MagicMock(),
        }):
            from modal_embedding_service import EmbedResponse
        fields = EmbedResponse.model_fields
        for required_field in ["vectors", "model", "dimension", "fallback"]:
            assert required_field in fields, f"EmbedResponse missing field: {required_field}"

    def test_classify_response_has_required_fields(self):
        """ClassifyResponse must have primary_kind, confidence, scores, model."""
        with patch.dict(sys.modules, {
            "transformers": MagicMock(),
            "torch": MagicMock(),
        }):
            from modal_classification_service import ClassifyResponse
        fields = ClassifyResponse.model_fields
        for required_field in ["primary_kind", "confidence", "scores", "model"]:
            assert required_field in fields, f"ClassifyResponse missing field: {required_field}"
