"""
conftest.py — Shared pytest fixtures for all Modal service unit and integration tests.

Provides:
  - Environment setup (JIMS_MODAL_API_KEY, service URLs)
  - modal_patch: patches the entire `modal` package so service files can be imported
  - valid_auth_headers: Authorization header for authenticated requests
"""
from __future__ import annotations

import os
import sys
import types
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# Environment bootstrap — set before any service module is imported
# ---------------------------------------------------------------------------

os.environ.setdefault("JIMS_MODAL_API_KEY", "test-secret")
os.environ.setdefault("JIMS_INTENT_SERVICE_URL", "http://intent.modal.test")
os.environ.setdefault("JIMS_RENDERER_SERVICE_URL", "http://renderer.modal.test")
os.environ.setdefault("JIMS_REASONING_SERVICE_URL", "http://reasoning.modal.test")
os.environ.setdefault("JIMS_EMBEDDING_SERVICE_URL", "http://embedding.modal.test")
os.environ.setdefault("JIMS_CLASSIFICATION_SERVICE_URL", "http://classification.modal.test")
os.environ.setdefault("JIMS_EMBEDDING_TIMEOUT", "8")
os.environ.setdefault("JIMS_GENERATION_TIMEOUT", "120")


# ---------------------------------------------------------------------------
# Modal stub module — injected into sys.modules so service files import cleanly
# without a live Modal account or container environment.
# ---------------------------------------------------------------------------

def _build_modal_stub() -> types.ModuleType:
    """Return a minimal mock of the `modal` package."""
    modal_mod = types.ModuleType("modal")

    # Decorators that are no-ops
    def _noop_decorator(*args, **kwargs):
        if len(args) == 1 and callable(args[0]):
            return args[0]
        def _wrap(fn):
            return fn
        return _wrap

    modal_mod.enter = _noop_decorator
    modal_mod.method = _noop_method_decorator
    modal_mod.asgi_app = _noop_decorator

    # App
    class _App:
        def __init__(self, name="", **kwargs):
            self.name = name
        def cls(self, *args, **kwargs):
            return _noop_decorator
        def function(self, *args, **kwargs):
            return _noop_decorator

    modal_mod.App = _App

    # Volume stub
    class _Volume:
        @staticmethod
        def from_name(name, create_if_missing=False):
            return MagicMock()

    modal_mod.Volume = _Volume

    # Secret stub
    class _Secret:
        @staticmethod
        def from_name(name):
            return MagicMock()

    modal_mod.Secret = _Secret

    # Image stub — supports chaining
    class _Image:
        def __init__(self, *args, **kwargs): pass
        def pip_install(self, *args, **kwargs): return self
        def run_commands(self, *args, **kwargs): return self
        def env(self, *args, **kwargs): return self

        @staticmethod
        def debian_slim(**kwargs):
            return _Image()

    modal_mod.Image = _Image

    # GPU stub
    class _GPU:
        class Any:
            def __init__(self, ordered=None): pass

    modal_mod.gpu = _GPU()

    return modal_mod


def _noop_method_decorator(*args, **kwargs):
    """Wrap a function so it can be called directly AND via .remote()."""
    if len(args) == 1 and callable(args[0]):
        fn = args[0]
        # Add a .remote() alias that calls the function directly
        fn.remote = fn
        return fn
    def _wrap(fn):
        fn.remote = fn
        return fn
    return _wrap


# Inject into sys.modules BEFORE any service file is imported
sys.modules.setdefault("modal", _build_modal_stub())


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def set_modal_api_key(monkeypatch):
    """Ensure JIMS_MODAL_API_KEY is set for every test."""
    monkeypatch.setenv("JIMS_MODAL_API_KEY", "test-secret")


@pytest.fixture()
def valid_auth_headers() -> dict[str, str]:
    """Authorization header that matches the test API key."""
    return {"Authorization": "Bearer test-secret"}


@pytest.fixture()
def invalid_auth_headers() -> dict[str, str]:
    """Authorization header with a wrong token."""
    return {"Authorization": "Bearer wrong-token"}


@pytest.fixture()
def no_auth_headers() -> dict[str, str]:
    """Request headers without any Authorization header."""
    return {}
