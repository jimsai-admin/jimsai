"""
test_embedding_service.py — Unit tests for modal_embedding_service.py

Tasks: 4.5
Requirements: 18.1, 18.2, 18.5, 18.6, 18.8
"""
from __future__ import annotations

import sys
import os
import types
from pathlib import Path
from unittest.mock import MagicMock, patch, call
import numpy as np
import pytest

# Ensure modal/ is on the path so `from shared.xxx import ...` resolves
_MODAL_DIR = Path(__file__).parent.parent
if str(_MODAL_DIR) not in sys.path:
    sys.path.insert(0, str(_MODAL_DIR))


# ---------------------------------------------------------------------------
# Patch heavy ML deps before importing the service
# ---------------------------------------------------------------------------

def _make_st_mock(dim=768):
    """Return a SentenceTransformer mock that produces random unit-norm vecs."""
    st = MagicMock()
    def encode(texts, normalize_embeddings=True):
        vecs = np.random.randn(len(texts), dim).astype(float)
        norms = np.linalg.norm(vecs, axis=1, keepdims=True)
        return (vecs / norms).tolist()
    st.encode.side_effect = encode
    return st


def _make_codebert_mock(dim=768):
    """Return AutoModel/AutoTokenizer mocks for codebert."""
    tok = MagicMock()
    tok_out = MagicMock()
    tok_out.__getitem__ = MagicMock(return_value=MagicMock())
    tok.return_value = tok_out

    model = MagicMock()
    import torch
    # last_hidden_state: (1, seq, dim)
    fake_hs = torch.randn(1, 8, dim)
    output = MagicMock()
    output.last_hidden_state = fake_hs
    model.return_value = output
    return tok, model


with patch.dict(sys.modules, {
    "sentence_transformers": MagicMock(),
    "transformers": MagicMock(),
    "torch": MagicMock(),
    "einops": MagicMock(),
}):
    # Ensure numpy is real
    import numpy  # noqa: F401
    from modal_embedding_service import (
        EmbedRequest, EmbedResponse, CodeEmbedRequest, web_app, EmbeddingService
    )

from fastapi.testclient import TestClient

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_service_with_mocks():
    """Create an EmbeddingService instance with mocked models."""
    svc = EmbeddingService.__new__(EmbeddingService)
    svc._models_loaded = {
        "multilingual-e5-small": True,
        "jina-v3": True,
        "codebert": True,
    }
    svc._volume_mounted = True
    svc._container_start_time = 0.0

    # Build mocks
    e5_mock = _make_st_mock(384)  # raw dim before padding
    jina_mock = _make_st_mock(768)

    import torch
    tok_mock = MagicMock()
    model_mock = MagicMock()
    fake_hs = torch.randn(1, 8, 768)
    out_mock = MagicMock()
    out_mock.last_hidden_state = fake_hs
    model_mock.return_value = out_mock
    tok_mock.return_value = {"input_ids": torch.zeros(1, 8, dtype=torch.long)}

    svc._e5_model = e5_mock
    svc._jina_model = jina_mock
    svc._codebert_tokenizer = tok_mock
    svc._codebert_model = model_mock

    return svc


# ---------------------------------------------------------------------------
# 4.5.1 — Model routing: each model key routes to correct instance
# ---------------------------------------------------------------------------

def test_embed_routes_to_e5():
    svc = _make_service_with_mocks()
    req = EmbedRequest(texts=["hello"], model="multilingual-e5-small", purpose="query")
    resp = svc.embed(req)
    assert svc._e5_model.encode.called
    assert resp.model == "multilingual-e5-small"


def test_embed_routes_to_jina():
    svc = _make_service_with_mocks()
    req = EmbedRequest(texts=["hello"], model="jina-v3", purpose="query")
    resp = svc.embed(req)
    assert svc._jina_model.encode.called
    assert resp.model == "jina-v3"


def test_embed_routes_to_codebert():
    svc = _make_service_with_mocks()
    req = EmbedRequest(texts=["def foo(): pass"], model="codebert", purpose="document")
    resp = svc.embed(req)
    assert resp.model == "codebert"


# ---------------------------------------------------------------------------
# 4.5.2 — Output shape: 768-d and unit-normalised
# ---------------------------------------------------------------------------

def test_embed_output_shape_e5():
    svc = _make_service_with_mocks()
    req = EmbedRequest(texts=["a", "b", "c"], model="multilingual-e5-small", purpose="query")
    resp = svc.embed(req)
    assert len(resp.vectors) == 3
    for v in resp.vectors:
        assert len(v) == 768
        norm = np.linalg.norm(v)
        assert abs(norm - 1.0) < 1e-3, f"norm={norm}"


def test_embed_output_shape_jina():
    svc = _make_service_with_mocks()
    req = EmbedRequest(texts=["x"], model="jina-v3", purpose="passage")
    resp = svc.embed(req)
    assert len(resp.vectors) == 1
    assert len(resp.vectors[0]) == 768
    assert abs(np.linalg.norm(resp.vectors[0]) - 1.0) < 1e-3


def test_embed_output_shape_codebert():
    svc = _make_service_with_mocks()
    req = EmbedRequest(texts=["print('hi')"], model="codebert")
    resp = svc.embed(req)
    assert len(resp.vectors[0]) == 768
    assert abs(np.linalg.norm(resp.vectors[0]) - 1.0) < 1e-3


# ---------------------------------------------------------------------------
# 4.5.3 — /embed/code always returns model == "codebert"
# ---------------------------------------------------------------------------

def test_embed_code_always_uses_codebert():
    svc = _make_service_with_mocks()
    req = CodeEmbedRequest(texts=["import os"])
    resp = svc.embed_code(req)
    assert resp.model == "codebert"


def test_embed_code_multiple_texts():
    svc = _make_service_with_mocks()
    req = CodeEmbedRequest(texts=["x=1", "y=2", "z=3"])
    resp = svc.embed_code(req)
    assert resp.model == "codebert"
    assert len(resp.vectors) == 3


# ---------------------------------------------------------------------------
# 4.5.4 — HTTP 422 on texts outside 1–128 range
# Test the service method directly (routes call svc.embed.remote() which
# requires a live Modal runtime; the validation logic lives in embed()).
# ---------------------------------------------------------------------------

def test_http_422_empty_texts():
    """embed() raises HTTPException 422 for empty texts list."""
    svc = _make_service_with_mocks()
    raised = None
    try:
        svc.embed(EmbedRequest(texts=[], model="multilingual-e5-small"))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected an exception but none was raised"
    assert getattr(raised, "status_code", None) == 422, f"Expected 422, got {raised}"


def test_http_422_too_many_texts():
    """embed() raises HTTPException 422 for texts list > 128."""
    svc = _make_service_with_mocks()
    raised = None
    try:
        svc.embed(EmbedRequest(texts=["x"] * 129, model="multilingual-e5-small"))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected an exception but none was raised"
    assert getattr(raised, "status_code", None) == 422, f"Expected 422, got {raised}"


def test_http_422_code_endpoint_empty_texts():
    """embed_code() raises HTTPException 422 for empty texts list."""
    svc = _make_service_with_mocks()
    raised = None
    try:
        svc.embed_code(CodeEmbedRequest(texts=[]))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected an exception but none was raised"
    assert getattr(raised, "status_code", None) == 422, f"Expected 422, got {raised}"


# ---------------------------------------------------------------------------
# 4.5.5 — HTTP 401 on missing/invalid auth header
# Test auth middleware directly via the web_app routes.
# Auth is checked before the service is even called.
# ---------------------------------------------------------------------------

def test_http_401_missing_auth():
    client = TestClient(web_app)
    resp = client.post("/embed", json={"texts": ["hi"], "model": "multilingual-e5-small"})
    assert resp.status_code == 401


def test_http_401_invalid_token(invalid_auth_headers):
    client = TestClient(web_app)
    resp = client.post(
        "/embed",
        json={"texts": ["hi"], "model": "multilingual-e5-small"},
        headers=invalid_auth_headers,
    )
    assert resp.status_code == 401


def test_http_401_missing_auth_code_endpoint():
    client = TestClient(web_app)
    resp = client.post("/embed/code", json={"texts": ["code"]})
    assert resp.status_code == 401


def test_health_endpoint():
    """Health method returns expected structure."""
    svc = _make_service_with_mocks()
    result = svc.health()
    assert "status" in result
    assert result.get("service") == "embedding"


# ---------------------------------------------------------------------------
# 4.5.6 — ensure_model_on_volume cache hit / cache miss
# ---------------------------------------------------------------------------

def test_ensure_model_cache_hit_no_download():
    """When validate_model_integrity returns True, no download should occur."""
    from shared.modal_common import ARTIFACT_REGISTRY

    with patch("shared.modal_common.validate_model_integrity", return_value=True) as mock_val, \
         patch("huggingface_hub.snapshot_download") as mock_dl:
        from shared.modal_common import ensure_model_on_volume
        artifact = ARTIFACT_REGISTRY["multilingual-e5-small"]
        ensure_model_on_volume(artifact)
        mock_val.assert_called_once()
        mock_dl.assert_not_called()


def test_ensure_model_cache_miss_triggers_download():
    """When validate_model_integrity returns False then True, download is triggered."""
    from shared.modal_common import ARTIFACT_REGISTRY

    # First call → False (miss), after download → True
    with patch("shared.modal_common.validate_model_integrity", side_effect=[False, True]), \
         patch("huggingface_hub.snapshot_download") as mock_dl, \
         patch("os.makedirs"):
        from shared.modal_common import ensure_model_on_volume
        artifact = ARTIFACT_REGISTRY["multilingual-e5-small"]
        result = ensure_model_on_volume(artifact)
        mock_dl.assert_called_once()
        assert "multilingual-e5-small" in str(result)
