"""
test_reasoning_service.py — Unit tests for modal_reasoning_service.py

Task: 9.5
Requirements: 18.4, 18.8, 27.2
"""
from __future__ import annotations

import sys
import threading
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

_MODAL_DIR = Path(__file__).parent.parent
if str(_MODAL_DIR) not in sys.path:
    sys.path.insert(0, str(_MODAL_DIR))

with patch.dict(sys.modules, {
    "llama_cpp": MagicMock(),
    "torch": MagicMock(),
}):
    from modal_reasoning_service import (
        GenerateRequest, GenerateResponse, ChatMessage, ReasoningService, web_app,
        _strip_think, _extract_json,
    )

from fastapi.testclient import TestClient


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_service(raw_content: str = "reasoning output", finish_reason: str = "stop"):
    svc = ReasoningService.__new__(ReasoningService)
    svc._model_loaded = True
    svc._volume_mounted = True
    svc._container_start_time = 0.0
    svc._lock = threading.Lock()
    svc._queue_depth = 0

    llm_mock = MagicMock()
    llm_mock.create_chat_completion.return_value = {
        "choices": [{"message": {"content": raw_content}, "finish_reason": finish_reason}],
        "usage": {"prompt_tokens": 10, "completion_tokens": 25},
    }
    svc._llm = llm_mock
    return svc


# ---------------------------------------------------------------------------
# 9.5.1 — Non-streaming response: model == "qwen-8b"
# ---------------------------------------------------------------------------

def test_response_model_is_qwen_8b():
    svc = _make_service()
    req = GenerateRequest(prompt="deep thought", stream=False)
    result = svc.generate(req)
    assert isinstance(result, GenerateResponse)
    assert result.model == "qwen-8b"


# ---------------------------------------------------------------------------
# 9.5.2 — GPU check: RuntimeError when no GPU
# ---------------------------------------------------------------------------

def test_strip_think_removes_blocks():
    """Use _strip_think helper to verify think-tag stripping (no GPU needed)."""
    assert _strip_think("<think>inner</think>result") == "result"
    assert _strip_think("no tags") == "no tags"


def test_extract_json_helper():
    assert _extract_json('prefix {"x": 2} suffix') == '{"x": 2}'


# ---------------------------------------------------------------------------
# 9.5.3 — HTTP 429 when queue depth >= 5
# ---------------------------------------------------------------------------

def test_http_429_when_queue_full():
    svc = _make_service()
    svc._queue_depth = 5
    raised = None
    try:
        svc.generate(GenerateRequest(prompt="overflow"))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 429, f"Expected 429, got {raised}"
    assert "Retry-After" in getattr(raised, "headers", {})


# ---------------------------------------------------------------------------
# 9.5.4 — HTTP 503 + llm reset on ggml_assert / repack
# ---------------------------------------------------------------------------

def test_ggml_assert_returns_503_and_resets():
    svc = _make_service()
    svc._llm.create_chat_completion.side_effect = RuntimeError("ggml_assert failure")
    raised = None
    try:
        svc.generate(GenerateRequest(prompt="x", stream=False))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 503, f"Expected 503, got {raised}"
    assert svc._llm is None
    assert "Retry-After" in getattr(raised, "headers", {})


def test_repack_error_returns_503_and_resets():
    svc = _make_service()
    svc._llm.create_chat_completion.side_effect = RuntimeError("repack corruption")
    raised = None
    try:
        svc.generate(GenerateRequest(prompt="x", stream=False))
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 503, f"Expected 503, got {raised}"
    assert svc._llm is None


# ---------------------------------------------------------------------------
# 9.5.5 — Think-tag stripping in JSON mode
# ---------------------------------------------------------------------------

def test_think_tag_stripped_in_json_mode():
    raw = "<think>step1</think>{\"result\": \"deep\"}"
    svc = _make_service(raw_content=raw)
    req = GenerateRequest(prompt="think", stream=False, response_format={"type": "json_object"})
    result = svc.generate(req)
    assert "<think>" not in result.response
    assert '"result"' in result.response


# ---------------------------------------------------------------------------
# 9.5.6 — HTTP 422 when no input provided
# ---------------------------------------------------------------------------

def test_http_422_no_input():
    svc = _make_service()
    raised = None
    try:
        svc.generate(GenerateRequest())
    except Exception as e:
        raised = e
    assert raised is not None, "Expected exception but none raised"
    assert getattr(raised, "status_code", None) == 422, f"Expected 422, got {raised}"


# ---------------------------------------------------------------------------
# 9.5.7 — Queue depth never goes negative
# ---------------------------------------------------------------------------

def test_queue_depth_never_negative_on_success():
    svc = _make_service()
    svc.generate(GenerateRequest(prompt="test", stream=False))
    assert svc._queue_depth >= 0


def test_queue_depth_never_negative_on_error():
    svc = _make_service()
    svc._llm.create_chat_completion.side_effect = RuntimeError("other error")
    raised = None
    try:
        svc.generate(GenerateRequest(prompt="x", stream=False))
    except Exception as e:
        raised = e
    assert svc._queue_depth >= 0


# ---------------------------------------------------------------------------
# 9.5.8 — min_containers=0 (scale-to-zero config — code check)
# ---------------------------------------------------------------------------

def test_min_containers_is_zero():
    """Verify the ReasoningService cls decorator uses min_containers=0."""
    import inspect
    import modal_reasoning_service as mod
    src = inspect.getsource(mod)
    # The @app.cls call should contain min_containers=0
    assert "min_containers=0" in src, "ReasoningService must be configured with min_containers=0"


# ---------------------------------------------------------------------------
# 9.5.9 — HTTP 401 via TestClient
# ---------------------------------------------------------------------------

def test_http_401_missing_auth():
    client = TestClient(web_app)
    resp = client.post("/generate", json={"prompt": "hello"})
    assert resp.status_code == 401


def test_http_401_wrong_token(invalid_auth_headers):
    client = TestClient(web_app)
    resp = client.post("/generate", json={"prompt": "hello"}, headers=invalid_auth_headers)
    assert resp.status_code == 401


def test_health_endpoint():
    svc = _make_service()
    result = svc.health()
    assert "status" in result
