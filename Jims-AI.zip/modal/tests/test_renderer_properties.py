"""
test_renderer_properties.py — Property-based tests for Renderer_Service.

Task: 7.6
Requirements: 19.4, 19.5

Properties:
  Property 10: Generation Model Routing Completeness
  Property 11: Lock Safety (concurrent calls serialised)
  Property 12: Think-Tag Stripping in JSON Mode
"""
from __future__ import annotations

import sys
import threading
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

_MODAL_DIR = Path(__file__).parent.parent
if str(_MODAL_DIR) not in sys.path:
    sys.path.insert(0, str(_MODAL_DIR))

from hypothesis import given, settings, HealthCheck, strategies as st

with patch.dict(sys.modules, {
    "llama_cpp": MagicMock(),
    "torch": MagicMock(),
}):
    from modal_renderer_service import (
        GenerateRequest, RendererService, _strip_think, _extract_json
    )

_HYPO_SETTINGS = settings(
    max_examples=20,
    suppress_health_check=[HealthCheck.too_slow],
    deadline=None,
)


def _make_service(raw_content: str = "response text"):
    svc = RendererService.__new__(RendererService)
    svc._model_loaded = True
    svc._volume_mounted = True
    svc._container_start_time = 0.0
    svc._lock = threading.Lock()
    svc._queue_depth = 0

    llm_mock = MagicMock()
    llm_mock.create_chat_completion.return_value = {
        "choices": [{"message": {"content": raw_content}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 5, "completion_tokens": 10},
    }
    svc._llm = llm_mock
    return svc


# ---------------------------------------------------------------------------
# Property 10: Generation Model Routing Completeness
# ---------------------------------------------------------------------------

@_HYPO_SETTINGS
@given(
    prompt=st.text(min_size=1, max_size=100),
)
def test_property_10_model_routing(prompt):
    """Response model must always be 'qwen-4b' for any valid prompt."""
    svc = _make_service()
    req = GenerateRequest(prompt=prompt, stream=False)
    result = svc.generate(req)
    assert result.model == "qwen-4b"


# ---------------------------------------------------------------------------
# Property 11: Lock Safety
# ---------------------------------------------------------------------------

@_HYPO_SETTINGS
@given(
    n_threads=st.integers(min_value=2, max_value=5),
    prompt=st.text(min_size=1, max_size=50),
)
def test_property_11_lock_safety(n_threads, prompt):
    """Concurrent threads must never hold the lock simultaneously."""
    svc = _make_service()
    concurrent_lock_holders = []
    lock_count = [0]
    errors = []

    original_lock_enter = svc._lock.__enter__

    def _track_enter():
        lock_count[0] += 1
        if lock_count[0] > 1:
            errors.append(f"Multiple threads held the lock: {lock_count[0]}")
        return original_lock_enter()

    def _track_exit(*args):
        lock_count[0] -= 1
        return svc._lock.__exit__(*args)

    results = []
    threads = []

    def _call():
        try:
            result = svc.generate(GenerateRequest(prompt=prompt, stream=False))
            results.append(result)
        except Exception as e:
            errors.append(str(e))

    for _ in range(n_threads):
        t = threading.Thread(target=_call)
        threads.append(t)

    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=5.0)

    # All threads should have completed (no deadlock)
    assert all(not t.is_alive() for t in threads), "Some threads are still alive — possible deadlock"
    # No GGUF errors expected (mock doesn't raise)
    assert not any("ggml_assert" in e for e in errors), f"Unexpected errors: {errors}"


# ---------------------------------------------------------------------------
# Property 12: Think-Tag Stripping in JSON Mode
# ---------------------------------------------------------------------------

@_HYPO_SETTINGS
@given(
    think_content=st.text(max_size=200),
    json_content=st.fixed_dictionaries({"key": st.text(max_size=50)}),
)
def test_property_12_think_tag_stripping(think_content, json_content):
    """For any input in json_object mode, response must contain no <think> blocks."""
    import json
    json_str = json.dumps(json_content)
    raw = f"<think>{think_content}</think>{json_str}"
    stripped = _strip_think(raw)
    assert "<think>" not in stripped
    assert "</think>" not in stripped


@_HYPO_SETTINGS
@given(
    think_text=st.text(max_size=100),
)
def test_property_12_strip_think_leaves_json(think_text):
    """After stripping think tags, the known JSON object is extractable."""
    import json
    # Build raw output with think block then a clean JSON object
    raw = f"<think>{think_text}</think>{{\"result\": 1}}"
    stripped = _strip_think(raw)
    result = _extract_json(stripped)
    # The extracted result must parse as valid JSON containing our key
    try:
        parsed = json.loads(result)
        assert parsed.get("result") == 1
    except json.JSONDecodeError:
        pytest.fail(f"_extract_json did not return valid JSON: {result!r}")
