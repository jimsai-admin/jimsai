"""
test_embedding_properties.py — Property-based tests for Embedding_Service.

Tasks: 4.6
Requirements: 19.1, 19.2, 19.3, 19.5

Properties tested:
  Property 3: Embedding Idempotency
  Property 4: Vector Dimensionality Invariant
  Property 5: Unit Norm Invariant
  Property 6: Output Count Matches Input Count
  Property 7: Code Endpoint Always Uses CodeBERT
  Property 9: Volume Idempotency
"""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch
import numpy as np
import pytest

_MODAL_DIR = Path(__file__).parent.parent
if str(_MODAL_DIR) not in sys.path:
    sys.path.insert(0, str(_MODAL_DIR))

from hypothesis import given, settings, HealthCheck, strategies as st

# ---------------------------------------------------------------------------
# Import service with mocked ML deps
# ---------------------------------------------------------------------------

with patch.dict(sys.modules, {
    "sentence_transformers": MagicMock(),
    "transformers": MagicMock(),
    "torch": MagicMock(),
    "einops": MagicMock(),
}):
    from modal_embedding_service import EmbedRequest, CodeEmbedRequest, EmbeddingService


_MODELS = ["multilingual-e5-small", "jina-v3", "codebert"]


def _make_deterministic_service():
    """Service with deterministic mock models (hash-based for reproducibility)."""
    import torch as real_torch
    svc = EmbeddingService.__new__(EmbeddingService)
    svc._models_loaded = {"multilingual-e5-small": True, "jina-v3": True, "codebert": True}
    svc._volume_mounted = True
    svc._container_start_time = 0.0

    def _stable_encode(texts, normalize_embeddings=True):
        """Deterministic encode: same text → same vector."""
        results = []
        for t in texts:
            seed = abs(hash(t)) % (2**31)
            rng = np.random.RandomState(seed)
            v = rng.randn(768).astype(float)
            v = v / np.linalg.norm(v)
            results.append(v.tolist())
        return results

    e5_mock = MagicMock()
    e5_mock.encode.side_effect = _stable_encode
    jina_mock = MagicMock()
    jina_mock.encode.side_effect = _stable_encode

    import torch as _torch
    tok_mock = MagicMock()
    model_mock = MagicMock()
    fake_hs = _torch.randn(1, 8, 768) if hasattr(_torch, "randn") else MagicMock()
    out_mock = MagicMock()
    out_mock.last_hidden_state = fake_hs
    model_mock.return_value = out_mock
    tok_mock.return_value = {"input_ids": MagicMock()}

    svc._e5_model = e5_mock
    svc._jina_model = jina_mock
    svc._codebert_tokenizer = tok_mock
    svc._codebert_model = model_mock
    return svc


_HYPO_SETTINGS = settings(
    max_examples=20,
    suppress_health_check=[HealthCheck.too_slow],
    deadline=None,
)


# ---------------------------------------------------------------------------
# Property 5: Unit Norm Invariant
# ---------------------------------------------------------------------------

@_HYPO_SETTINGS
@given(
    texts=st.lists(st.text(min_size=1, max_size=100), min_size=1, max_size=5),
    model=st.sampled_from(_MODELS),
)
def test_property_5_unit_norm(texts, model):
    """All output vectors must have L2 norm within 1e-3 of 1.0."""
    svc = _make_deterministic_service()
    req = EmbedRequest(texts=texts, model=model)
    resp = svc.embed(req)
    for v in resp.vectors:
        norm = float(np.linalg.norm(v))
        assert abs(norm - 1.0) < 1e-3, f"norm={norm:.6f} for model={model}"


# ---------------------------------------------------------------------------
# Property 6: Output Count Matches Input Count
# ---------------------------------------------------------------------------

@_HYPO_SETTINGS
@given(
    texts=st.lists(st.text(min_size=1, max_size=100), min_size=1, max_size=10),
    model=st.sampled_from(_MODELS),
)
def test_property_6_output_count(texts, model):
    """len(response.vectors) == len(texts) for any valid batch."""
    svc = _make_deterministic_service()
    req = EmbedRequest(texts=texts, model=model)
    resp = svc.embed(req)
    assert len(resp.vectors) == len(texts)


# ---------------------------------------------------------------------------
# Property 4: Vector Dimensionality Invariant
# ---------------------------------------------------------------------------

@_HYPO_SETTINGS
@given(
    texts=st.lists(st.text(min_size=1, max_size=100), min_size=1, max_size=5),
    model=st.sampled_from(_MODELS),
)
def test_property_4_dimensionality(texts, model):
    """Every vector must have exactly 768 dimensions."""
    svc = _make_deterministic_service()
    req = EmbedRequest(texts=texts, model=model)
    resp = svc.embed(req)
    for v in resp.vectors:
        assert len(v) == 768, f"dim={len(v)} for model={model}"


# ---------------------------------------------------------------------------
# Property 7: Code Endpoint Always Uses CodeBERT
# ---------------------------------------------------------------------------

@_HYPO_SETTINGS
@given(texts=st.lists(st.text(min_size=1, max_size=100), min_size=1, max_size=5))
def test_property_7_code_endpoint_codebert(texts):
    """POST /embed/code must always return model='codebert'."""
    svc = _make_deterministic_service()
    req = CodeEmbedRequest(texts=texts)
    resp = svc.embed_code(req)
    assert resp.model == "codebert"


# ---------------------------------------------------------------------------
# Property 3: Embedding Idempotency
# ---------------------------------------------------------------------------

@_HYPO_SETTINGS
@given(
    texts=st.lists(st.text(min_size=1, max_size=50), min_size=1, max_size=3),
)
def test_property_3_idempotency(texts):
    """Same texts → cosine similarity ≥ 0.9999 between two calls."""
    svc = _make_deterministic_service()
    req = EmbedRequest(texts=texts, model="multilingual-e5-small", purpose="query")
    resp1 = svc.embed(req)
    resp2 = svc.embed(req)
    for v1, v2 in zip(resp1.vectors, resp2.vectors):
        a, b = np.array(v1), np.array(v2)
        cos_sim = float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9))
        assert cos_sim >= 0.9999, f"cos_sim={cos_sim:.6f}"


# ---------------------------------------------------------------------------
# Property 9: Volume Idempotency
# ---------------------------------------------------------------------------

@_HYPO_SETTINGS
@given(model_key=st.sampled_from(["multilingual-e5-small", "jina-v3", "codebert"]))
def test_property_9_volume_idempotency(model_key):
    """Calling ensure_model_on_volume twice for a cached artifact triggers no extra download."""
    from shared.modal_common import ARTIFACT_REGISTRY

    download_count = [0]

    def _mock_download(*args, **kwargs):
        download_count[0] += 1

    with patch("shared.modal_common.validate_model_integrity", return_value=True), \
         patch("huggingface_hub.snapshot_download", side_effect=_mock_download), \
         patch("huggingface_hub.hf_hub_download", side_effect=_mock_download):
        from shared.modal_common import ensure_model_on_volume
        artifact = ARTIFACT_REGISTRY[model_key]
        ensure_model_on_volume(artifact)
        ensure_model_on_volume(artifact)

    assert download_count[0] == 0, f"Expected 0 downloads for cached {model_key}, got {download_count[0]}"
