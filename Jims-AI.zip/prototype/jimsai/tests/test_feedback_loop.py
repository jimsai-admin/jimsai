"""Tests for the closed feedback loop — graph.reinforce() and confidence decay."""

from __future__ import annotations

import asyncio
import sys
import pathlib
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).parents[3]))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_signature(sig_id: str, confidence: float = 0.80, has_causal: bool = True):
    """Build a minimal MemorySignature for testing."""
    from prototype.jimsai.models import (
        CausalLink, Confidence, Entity, MemorySignature, Modality,
        Relation, SignatureIntent, StructuredSignature, Importance,
    )
    from datetime import datetime, timezone

    causal = [CausalLink(cause="high_cpu", effect="slow_response", confidence=0.85)] if has_causal else []
    relations = [Relation(subject="high_cpu", predicate="causes", object="slow_response", confidence=0.85)] if has_causal else []

    sig = MemorySignature(
        id=sig_id,
        provenance="test",
        structured=StructuredSignature(
            entities=[Entity(id="ent_cpu", name="high_cpu", type="state")],
            relations=relations,
            causal_chain=causal,
            intent=SignatureIntent(type="workspace_query", certainty="confirmed"),
        ),
        latent_embedding=[0.1] * 64,
        abstraction_tags=["cpu", "performance"],
        confidence=Confidence(score=confidence, source="test"),
        modality=Modality.TEXT,
        linked_signatures=[],
        raw_excerpt="High CPU usage causes slow response times.",
    )
    return sig


def _make_feedback_request(
    rating: str,
    trace_id: str = "trace_001",
    source_ids: list[str] | None = None,
):
    from prototype.jimsai.models import FeedbackRequest
    # Map friendly names to valid FeedbackRequest rating literals
    rating_map = {
        "accept": "positive", "thumbs_up": "positive", "approve": "positive",
        "reject": "negative", "thumbs_down": "negative", "deny": "negative",
    }
    valid_rating = rating_map.get(rating, rating)
    req = FeedbackRequest(
        trace_id=trace_id,
        user_id="user_test",
        workspace_id="ws_test",
        rating=valid_rating,
        notes="",
        source_signature_ids=source_ids or [],
    )
    return req


# ---------------------------------------------------------------------------
# graph.reinforce() called on positive feedback
# ---------------------------------------------------------------------------

class TestPositiveFeedback:
    @pytest.mark.asyncio
    async def test_reinforce_called_for_accept(self):
        from prototype.jimsai.graph import CausalGraphEngine
        from prototype.jimsai.memory import FourLayerMemoryStore

        sig = _make_signature("sig_001", confidence=0.80, has_causal=True)
        memory = FourLayerMemoryStore()
        memory.insert(sig)
        graph = MagicMock(spec=CausalGraphEngine)

        # Build a minimal pipeline with mocked internals
        from prototype.jimsai import pipeline as pl_module
        with patch.object(pl_module.JimsAIPipeline, "__init__", lambda self: None):
            p = pl_module.JimsAIPipeline.__new__(pl_module.JimsAIPipeline)
            p.memory = memory
            p.graph = graph
            p.feedback_events = []
            p.feedback_history = []
            p.production = MagicMock()
            p.production.save_user_feedback = MagicMock()
            p.production.save_panel_items = MagicMock()
            p.event_store = MagicMock()
            p.event_store.append = MagicMock()

            # Provide minimal _feedback_item implementation
            from prototype.jimsai.models import TrainingPanelItem, utc_now
            def _feedback_item(record, index):
                return TrainingPanelItem(
                    id=f"feedback:{index}",
                    panel="feedback",
                    kind="feedback_event",
                    title="test",
                    subtitle="test",
                    data=record,
                    created_at=utc_now(),
                )
            p._feedback_item = _feedback_item

            request = _make_feedback_request("accept", source_ids=["sig_001"])
            await p.record_feedback(request)

        # graph.reinforce should have been called for the causal link
        graph.reinforce.assert_called()
        calls = [str(c) for c in graph.reinforce.call_args_list]
        assert any("high_cpu" in c for c in calls)

    @pytest.mark.asyncio
    async def test_reinforce_called_for_thumbs_up(self):
        from prototype.jimsai.graph import CausalGraphEngine
        from prototype.jimsai.memory import FourLayerMemoryStore

        sig = _make_signature("sig_002", confidence=0.80, has_causal=True)
        memory = FourLayerMemoryStore()
        memory.insert(sig)
        graph = MagicMock(spec=CausalGraphEngine)

        from prototype.jimsai import pipeline as pl_module
        with patch.object(pl_module.JimsAIPipeline, "__init__", lambda self: None):
            p = pl_module.JimsAIPipeline.__new__(pl_module.JimsAIPipeline)
            p.memory = memory
            p.graph = graph
            p.feedback_events = []
            p.feedback_history = []
            p.production = MagicMock()
            p.production.save_user_feedback = MagicMock()
            p.production.save_panel_items = MagicMock()
            p.event_store = MagicMock()
            p.event_store.append = MagicMock()
            from prototype.jimsai.models import TrainingPanelItem, utc_now
            def _feedback_item(record, index):
                return TrainingPanelItem(id=f"f:{index}", panel="feedback", kind="feedback_event",
                                         title="t", subtitle="s", data=record, created_at=utc_now())
            p._feedback_item = _feedback_item

            request = _make_feedback_request("thumbs_up", source_ids=["sig_002"])
            await p.record_feedback(request)

        graph.reinforce.assert_called()

    @pytest.mark.asyncio
    async def test_no_reinforce_when_no_source_ids(self):
        from prototype.jimsai.graph import CausalGraphEngine
        graph = MagicMock(spec=CausalGraphEngine)
        from prototype.jimsai.memory import FourLayerMemoryStore

        from prototype.jimsai import pipeline as pl_module
        with patch.object(pl_module.JimsAIPipeline, "__init__", lambda self: None):
            p = pl_module.JimsAIPipeline.__new__(pl_module.JimsAIPipeline)
            p.memory = FourLayerMemoryStore()
            p.graph = graph
            p.feedback_events = []
            p.feedback_history = []
            p.production = MagicMock()
            p.production.save_user_feedback = MagicMock()
            p.production.save_panel_items = MagicMock()
            p.event_store = MagicMock()
            p.event_store.append = MagicMock()
            from prototype.jimsai.models import TrainingPanelItem, utc_now
            p._feedback_item = lambda r, i: TrainingPanelItem(
                id=f"f:{i}", panel="feedback", kind="feedback_event",
                title="t", subtitle="s", data=r, created_at=utc_now())

            request = _make_feedback_request("accept", source_ids=[])
            await p.record_feedback(request)

        graph.reinforce.assert_not_called()


# ---------------------------------------------------------------------------
# Confidence decay on negative feedback
# ---------------------------------------------------------------------------

class TestNegativeFeedback:
    @pytest.mark.asyncio
    async def test_confidence_decays_on_reject(self):
        from prototype.jimsai.memory import FourLayerMemoryStore
        from prototype.jimsai.graph import CausalGraphEngine

        sig = _make_signature("sig_003", confidence=0.80)
        memory = FourLayerMemoryStore()
        memory.insert(sig)
        graph = MagicMock(spec=CausalGraphEngine)

        from prototype.jimsai import pipeline as pl_module
        with patch.object(pl_module.JimsAIPipeline, "__init__", lambda self: None):
            p = pl_module.JimsAIPipeline.__new__(pl_module.JimsAIPipeline)
            p.memory = memory
            p.graph = graph
            p.feedback_events = []
            p.feedback_history = []
            p.production = MagicMock()
            p.production.save_user_feedback = MagicMock()
            p.production.save_panel_items = MagicMock()
            p.event_store = MagicMock()
            p.event_store.append = MagicMock()
            from prototype.jimsai.models import TrainingPanelItem, utc_now
            p._feedback_item = lambda r, i: TrainingPanelItem(
                id=f"f:{i}", panel="feedback", kind="feedback_event",
                title="t", subtitle="s", data=r, created_at=utc_now())

            request = _make_feedback_request("reject", source_ids=["sig_003"])
            await p.record_feedback(request)

        updated = memory.get("sig_003")
        assert updated is not None
        assert updated.confidence.score < 0.80  # should have decayed
        assert updated.confidence.score >= 0.10  # floor respected

    @pytest.mark.asyncio
    async def test_confidence_floor_respected(self):
        from prototype.jimsai.memory import FourLayerMemoryStore
        from prototype.jimsai.graph import CausalGraphEngine

        sig = _make_signature("sig_004", confidence=0.12)  # already near floor
        memory = FourLayerMemoryStore()
        memory.insert(sig)
        graph = MagicMock(spec=CausalGraphEngine)

        from prototype.jimsai import pipeline as pl_module
        with patch.object(pl_module.JimsAIPipeline, "__init__", lambda self: None):
            p = pl_module.JimsAIPipeline.__new__(pl_module.JimsAIPipeline)
            p.memory = memory
            p.graph = graph
            p.feedback_events = []
            p.feedback_history = []
            p.production = MagicMock()
            p.production.save_user_feedback = MagicMock()
            p.production.save_panel_items = MagicMock()
            p.event_store = MagicMock()
            p.event_store.append = MagicMock()
            from prototype.jimsai.models import TrainingPanelItem, utc_now
            p._feedback_item = lambda r, i: TrainingPanelItem(
                id=f"f:{i}", panel="feedback", kind="feedback_event",
                title="t", subtitle="s", data=r, created_at=utc_now())

            request = _make_feedback_request("thumbs_down", source_ids=["sig_004"])
            await p.record_feedback(request)

        updated = memory.get("sig_004")
        assert updated.confidence.score >= 0.10


# ---------------------------------------------------------------------------
# _learn_from_resolved_prompt — threshold tests
# ---------------------------------------------------------------------------

class TestResolutionLearning:
    def _make_pipeline_with_mocks(self):
        from prototype.jimsai import pipeline as pl_module
        from prototype.jimsai.memory import FourLayerMemoryStore
        from prototype.jimsai.graph import CausalGraphEngine
        from prototype.jimsai.encoder.dual_encoder import DualRepresentationEncoder

        with patch.object(pl_module.JimsAIPipeline, "__init__", lambda self: None):
            p = pl_module.JimsAIPipeline.__new__(pl_module.JimsAIPipeline)
            p.memory = FourLayerMemoryStore()
            p.graph = MagicMock(spec=CausalGraphEngine)
            p.encoder = DualRepresentationEncoder(multimodal_adapter=None)
            p.production = MagicMock()
            p.production.save_training_ingest = MagicMock()
            p.event_store = MagicMock()
            p.event_store.append = MagicMock()
            return p

    def _make_response(self, confidence: float, has_gaps: bool, has_executed: bool):
        from prototype.jimsai.models import CapabilityExecutionResult, CapabilityKind, CapabilityPlan

        executed = []
        if has_executed:
            result = MagicMock(spec=CapabilityExecutionResult)
            result.data = {"executed": True, "solver_status": "solved"}
            result.confidence = 0.99
            result.provenance = "internal_symbolic_solver"
            # model_dump must return the real data dict for the code to inspect
            result.model_dump = MagicMock(return_value={
                "executed": True, "solver_status": "solved",
                "kind": "math_science", "confidence": 0.99,
            })
            executed.append(result)

        plan = MagicMock(spec=CapabilityPlan)
        plan.kind = MagicMock()
        plan.kind.value = "math_science"
        plan.route = "math"
        plan.routing_signals = {}

        response = MagicMock()
        response.confidence = confidence
        response.gaps = ["unknown gap"] if has_gaps else []
        response.capability_results = executed
        response.capability_plan = plan
        response.response = "The answer is 7."
        response.sources = ["sig_abc"]
        response.ir = MagicMock()
        response.ir.trace_id = "trace_xyz"
        response.used_groq = False
        return response

    def _make_request(self):
        from prototype.jimsai.models import PipelineRequest, Modality
        return PipelineRequest(
            query="What is 3x - 7 = 14?",
            user_id="user_01",
            workspace_id="ws_01",
            modality=Modality.TEXT,
        )

    def test_does_not_write_below_090_threshold(self, monkeypatch):
        monkeypatch.setenv("JIMS_RESOLUTION_LEARNING_MIN_CONFIDENCE", "0.90")
        p = self._make_pipeline_with_mocks()
        before_count = len(p.memory.all_signatures())

        response = self._make_response(confidence=0.85, has_gaps=False, has_executed=True)
        request = self._make_request()
        p._learn_from_resolved_prompt(request, response)

        assert len(p.memory.all_signatures()) == before_count  # nothing written

    def test_writes_at_090_threshold_no_gaps_with_executed(self, monkeypatch):
        """Resolution learning writes to the training pipeline (not live memory).
        Memory insert is intentionally disabled to prevent cross-query retrieval
        contamination — only save_training_ingest is called.
        """
        monkeypatch.setenv("JIMS_RESOLUTION_LEARNING_MIN_CONFIDENCE", "0.90")
        p = self._make_pipeline_with_mocks()
        before_count = len(p.memory.all_signatures())

        response = self._make_response(confidence=0.92, has_gaps=False, has_executed=True)
        request = self._make_request()
        p._learn_from_resolved_prompt(request, response)

        # Memory insert is intentionally removed — resolution signatures go to
        # training pipeline only, not live retrieval memory.
        assert len(p.memory.all_signatures()) == before_count  # no live memory write
        assert p.production.save_training_ingest.called  # training pipeline was written

    def test_does_not_write_when_gaps_present(self, monkeypatch):
        monkeypatch.setenv("JIMS_RESOLUTION_LEARNING_MIN_CONFIDENCE", "0.90")
        p = self._make_pipeline_with_mocks()
        before_count = len(p.memory.all_signatures())

        response = self._make_response(confidence=0.95, has_gaps=True, has_executed=True)
        request = self._make_request()
        p._learn_from_resolved_prompt(request, response)

        assert len(p.memory.all_signatures()) == before_count  # blocked by gaps

    def test_does_not_write_without_executed_results(self, monkeypatch):
        monkeypatch.setenv("JIMS_RESOLUTION_LEARNING_MIN_CONFIDENCE", "0.90")
        p = self._make_pipeline_with_mocks()
        before_count = len(p.memory.all_signatures())

        response = self._make_response(confidence=0.95, has_gaps=False, has_executed=False)
        request = self._make_request()
        p._learn_from_resolved_prompt(request, response)

        assert len(p.memory.all_signatures()) == before_count  # no executed results
