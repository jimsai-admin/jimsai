"""Tests for ExternalMultimodalEncoderAdapter — validates Modal embedding wiring."""

from __future__ import annotations

import sys
import pathlib
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).parents[3]))

from prototype.jimsai.models import Modality


# ---------------------------------------------------------------------------
# Helpers — build adapter with minimal settings
# ---------------------------------------------------------------------------

def _make_adapter(url: str = "https://jimstechai--jimsai-embedding-service-fastapi-app.modal.run", token: str = "tok"):
    from prototype.jimsai.provider_adapters import (
        ExternalMultimodalEncoderAdapter,
        ProductionSettings,
    )
    settings = ProductionSettings(
        strict_provider_startup=False,
        supabase_url="",
        supabase_service_key="",
        supabase_anon_key="",
        graph_provider="neo4j_aura",
        neo4j_uri="",
        neo4j_user="neo4j",
        neo4j_password="",
        neo4j_database="neo4j",
        redis_url="",
        r2_account_id="",
        r2_bucket="",
        r2_access_key="",
        r2_secret_key="",
        vectorize_account_id="",
        vectorize_api_token="",
        vectorize_index="",
        vectorize_dimensions=768,
        embedding_service_url=url,
        embedding_service_token=token,
    )
    return ExternalMultimodalEncoderAdapter(settings)


# ---------------------------------------------------------------------------
# configured property
# ---------------------------------------------------------------------------

class TestAdapterConfigured:
    def test_configured_when_url_set(self):
        adapter = _make_adapter(url="https://jimstechai--jimsai-embedding-service-fastapi-app.modal.run")
        assert adapter.configured is True

    def test_not_configured_when_url_empty(self):
        adapter = _make_adapter(url="")
        assert adapter.configured is False


# ---------------------------------------------------------------------------
# encode() — text modality uses multilingual-e5-small (Modal short name)
# ---------------------------------------------------------------------------

class TestEncodeText:
    def test_returns_768_dim_vector_for_text(self):
        adapter = _make_adapter()
        fake_vec = [0.1] * 768

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "vectors": [fake_vec],
            "model": "multilingual-e5-small",
            "dimension": 768,
            "fallback": False,
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.post", return_value=mock_response) as mock_post:
            result = adapter.encode("hello world", Modality.TEXT)

        assert len(result) == 768
        # Verify Modal short model name and correct path
        call_kwargs = mock_post.call_args[1]
        assert call_kwargs["json"]["model"] == "multilingual-e5-small"
        assert call_kwargs["json"]["purpose"] == "query"
        assert "/embed" in mock_post.call_args[0][0]

    def test_returns_empty_on_http_error(self):
        adapter = _make_adapter()

        with patch("httpx.post", side_effect=Exception("timeout")):
            result = adapter.encode("hello world", Modality.TEXT)

        assert result == []

    def test_not_configured_returns_empty(self):
        adapter = _make_adapter(url="")
        result = adapter.encode("hello", Modality.TEXT)
        assert result == []


# ---------------------------------------------------------------------------
# encode() — code modality uses codebert (Modal short name)
# ---------------------------------------------------------------------------

class TestEncodeCode:
    def test_uses_codebert_for_code_modality(self):
        adapter = _make_adapter()
        fake_vec = [0.05] * 768

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "vectors": [fake_vec],
            "model": "codebert",
            "dimension": 768,
            "fallback": False,
        }
        mock_response.raise_for_status = MagicMock()

        with patch("httpx.post", return_value=mock_response) as mock_post:
            result = adapter.encode("def foo(): pass", Modality.CODE)

        assert len(result) == 768
        call_kwargs = mock_post.call_args[1]
        assert call_kwargs["json"]["model"] == "codebert"
        assert call_kwargs["json"]["purpose"] == "document"

    def test_code_fallback_returns_empty_on_error(self):
        adapter = _make_adapter()
        with patch("httpx.post", side_effect=Exception("connection refused")):
            result = adapter.encode("def foo(): pass", Modality.CODE)
        assert result == []


# ---------------------------------------------------------------------------
# DualRepresentationEncoder integration — latent_embedding_source
# ---------------------------------------------------------------------------

class TestDualEncoderIntegration:
    def test_sets_external_service_source_when_adapter_returns_vector(self):
        from prototype.jimsai.encoder.dual_encoder import DualRepresentationEncoder

        fake_vec = [0.1] * 768
        mock_adapter = MagicMock()
        mock_adapter.encode.return_value = fake_vec

        encoder = DualRepresentationEncoder(multimodal_adapter=mock_adapter)
        sig = encoder.encode("test content", modality=Modality.TEXT)

        assert sig.metadata.get("latent_embedding_source") == "external_service"
        assert sig.latent_embedding == fake_vec

    def test_sets_hash_projection_source_when_adapter_unavailable(self):
        from prototype.jimsai.encoder.dual_encoder import DualRepresentationEncoder

        mock_adapter = MagicMock()
        mock_adapter.encode.return_value = []  # empty = unavailable

        encoder = DualRepresentationEncoder(multimodal_adapter=mock_adapter)
        sig = encoder.encode("test content", modality=Modality.TEXT)

        assert sig.metadata.get("latent_embedding_source") == "hash_projection"
        assert sig.metadata.get("reembedding_required") is True

    def test_no_adapter_falls_back_to_hash(self):
        from prototype.jimsai.encoder.dual_encoder import DualRepresentationEncoder

        encoder = DualRepresentationEncoder(multimodal_adapter=None)
        sig = encoder.encode("test content", modality=Modality.TEXT)

        assert len(sig.latent_embedding) > 0

    def test_external_service_source_on_code_modality(self):
        from prototype.jimsai.encoder.dual_encoder import DualRepresentationEncoder

        fake_vec = [0.02] * 768
        mock_adapter = MagicMock()
        mock_adapter.encode.return_value = fake_vec

        encoder = DualRepresentationEncoder(multimodal_adapter=mock_adapter)
        sig = encoder.encode("def sort_list(lst): return sorted(lst)", modality=Modality.CODE)

        assert sig.metadata.get("latent_embedding_source") == "external_service"
        call_args = mock_adapter.encode.call_args
        assert call_args[0][1] == Modality.CODE


# ---------------------------------------------------------------------------
# _extract_vector — response format parsing (Modal returns "vectors" key)
# ---------------------------------------------------------------------------

class TestExtractVector:
    def test_parses_vectors_list_format(self):
        """Modal primary response shape: {"vectors": [[...]]}"""
        adapter = _make_adapter()
        vec = [0.5, 0.6, 0.7]
        result = adapter._extract_vector({"vectors": [vec]})
        assert len(result) == 3

    def test_parses_openai_data_format(self):
        """Legacy OpenAI shape: {"data": [{"embedding": [...]}]}"""
        adapter = _make_adapter()
        vec = [0.1, 0.2, 0.3]
        result = adapter._extract_vector({"data": [{"embedding": vec}]})
        assert len(result) == 3

    def test_parses_embeddings_list_format(self):
        """Legacy HF shape: {"embeddings": [[...]]}"""
        adapter = _make_adapter()
        vec = [0.1, 0.2]
        result = adapter._extract_vector({"embeddings": [vec]})
        assert len(result) == 2

    def test_returns_empty_on_unparseable_payload(self):
        adapter = _make_adapter()
        result = adapter._extract_vector({"unknown_key": "something"})
        assert result == []
