"""Tests for QwenBridge — validates Modal LLM routing (intent + renderer)."""

from __future__ import annotations

import json
import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parents[3]))

from prototype.jimsai.model_bridge import QwenBridge


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_bridge(intent_url="https://jimstechai--jimsai-intent-service-fastapi-app.modal.run",
                 renderer_url="https://jimstechai--jimsai-renderer-service-fastapi-app.modal.run",
                 api_key="tok"):
    """Build a QwenBridge with controlled attributes, bypassing env vars."""
    bridge = QwenBridge.__new__(QwenBridge)
    bridge.local_url = intent_url
    bridge.render_url = renderer_url
    bridge.local_api_key = api_key
    bridge.local_model = "qwen3-1.7b-instruct"
    bridge.local_render_model = "qwen3-4b-instruct"
    bridge.local_chat_path = "/generate"
    bridge.local_render_path = "/generate"
    bridge.adaptive_thinning = True
    bridge.t1_skip_confidence = 0.68
    bridge.t2_skip_confidence = 0.95
    bridge.last_t1_skip_reason = ""
    bridge.last_t2_skip_reason = ""
    return bridge


# ---------------------------------------------------------------------------
# Availability
# ---------------------------------------------------------------------------

class TestQwenBridgeAvailability:
    def test_available_when_both_urls_and_key_set(self):
        bridge = _make_bridge()
        assert bridge.available is True
        assert bridge.qwen_enabled is True

    def test_unavailable_when_intent_url_empty(self):
        bridge = _make_bridge(intent_url="")
        assert bridge.available is False
        assert bridge.qwen_enabled is False

    def test_unavailable_when_renderer_url_empty(self):
        bridge = _make_bridge(renderer_url="")
        assert bridge.available is False
        assert bridge.qwen_enabled is False

    def test_unavailable_when_api_key_empty(self):
        bridge = _make_bridge(api_key="")
        assert bridge.available is False
        assert bridge.qwen_enabled is False

    def test_groq_bridge_alias_works(self):
        """QwenBridge is the canonical class."""
        assert QwenBridge is not None

    def test_init_reads_modal_env_vars(self, monkeypatch):
        monkeypatch.setenv("JIMS_INTENT_SERVICE_URL", "https://intent.modal.run")
        monkeypatch.setenv("JIMS_RENDERER_SERVICE_URL", "https://renderer.modal.run")
        monkeypatch.setenv("JIMS_MODAL_API_KEY", "test-key")
        bridge = QwenBridge()
        assert bridge.local_url == "https://intent.modal.run"
        assert bridge.render_url == "https://renderer.modal.run"
        assert bridge.local_api_key == "test-key"
        assert bridge.qwen_enabled is True

    def test_no_groq_model_attributes(self):
        """Old Groq-specific attributes must not exist."""
        bridge = _make_bridge()
        assert not hasattr(bridge, "intent_model")
        assert not hasattr(bridge, "allow_external_groq")
        assert not hasattr(bridge, "enabled_t1")
        assert not hasattr(bridge, "enabled_t2")


# ---------------------------------------------------------------------------
# T1 skip logic
# ---------------------------------------------------------------------------

class TestShouldSkipT1:
    def test_skip_when_high_confidence(self):
        bridge = _make_bridge()
        ir = {"target_ir": "WORKSPACE_QUERY", "confidence": 0.90}
        assert bridge._should_skip_t1(ir) is True

    def test_no_skip_when_low_confidence(self):
        bridge = _make_bridge()
        ir = {"target_ir": "WORKSPACE_QUERY", "confidence": 0.50}
        assert bridge._should_skip_t1(ir) is False

    def test_never_skip_sandbox(self):
        bridge = _make_bridge()
        ir = {"target_ir": "OP_ESCAPE_TO_SANDBOX", "confidence": 0.99}
        assert bridge._should_skip_t1(ir) is False

    def test_never_skip_code_generate(self):
        bridge = _make_bridge()
        ir = {"target_ir": "CODE_GENERATE", "confidence": 0.99}
        assert bridge._should_skip_t1(ir) is False

    def test_no_skip_when_thinning_disabled(self):
        bridge = _make_bridge()
        bridge.adaptive_thinning = False
        ir = {"target_ir": "WORKSPACE_QUERY", "confidence": 0.99}
        assert bridge._should_skip_t1(ir) is False


# ---------------------------------------------------------------------------
# infer_intent
# ---------------------------------------------------------------------------

class TestInferIntent:
    @pytest.mark.asyncio
    async def test_returns_none_when_qwen_unavailable(self):
        bridge = _make_bridge(intent_url="", renderer_url="")
        result = await bridge.infer_intent("hello", {"confidence": 0.5, "target_ir": "WORKSPACE_QUERY"})
        assert result is None
        assert bridge.last_t1_skip_reason == "qwen_unavailable"

    @pytest.mark.asyncio
    async def test_returns_none_when_high_confidence_skip(self):
        bridge = _make_bridge()
        result = await bridge.infer_intent(
            "what is x", {"confidence": 0.90, "target_ir": "WORKSPACE_QUERY"}
        )
        assert result is None
        assert "deterministic_confidence" in bridge.last_t1_skip_reason

    @pytest.mark.asyncio
    async def test_passes_through_modal_json_response(self):
        bridge = _make_bridge()
        expected = {"target_ir": "CODE_GENERATE", "confidence": 0.88}

        async def mock_local(*args, **kwargs):
            return expected

        bridge._local_chat_json = mock_local
        result = await bridge.infer_intent(
            "write a function",
            {"confidence": 0.45, "target_ir": "OP_ESCAPE_TO_SANDBOX"},
        )
        assert result == expected


# ---------------------------------------------------------------------------
# render
# ---------------------------------------------------------------------------

class TestRender:
    @pytest.mark.asyncio
    async def test_returns_none_when_qwen_unavailable(self):
        bridge = _make_bridge(intent_url="", renderer_url="")
        obj = MagicMock()
        result = await bridge.render(obj, "fallback text")
        assert result is None
        assert bridge.last_t2_skip_reason == "qwen_unavailable"

    @pytest.mark.asyncio
    async def test_returns_rendered_string_from_modal(self):
        bridge = _make_bridge()

        async def mock_render(*args, **kwargs):
            return {"response": "Here is your answer."}

        bridge._render_chat_json = mock_render

        obj = MagicMock()
        obj.knowledge_gaps = []
        obj.generation_mode = "CREATIVE"  # prevents t2 skip
        obj.sources = ["sig_abc"]
        obj.confidence = 0.85
        obj.style_signature = {
            "user_prompt": "tell me something",
            "language_hint": "default",
            "format_hint": "default",
        }
        obj.model_dump = MagicMock(return_value={})

        result = await bridge.render(obj, "deterministic fallback")
        assert result == "Here is your answer."

    @pytest.mark.asyncio
    async def test_returns_none_when_render_returns_none(self):
        bridge = _make_bridge()

        async def mock_render(*args, **kwargs):
            return None

        bridge._render_chat_json = mock_render

        obj = MagicMock()
        obj.knowledge_gaps = []
        obj.generation_mode = "CREATIVE"
        obj.sources = ["sig_abc"]
        obj.confidence = 0.85
        obj.style_signature = {"user_prompt": "x", "language_hint": "default", "format_hint": "default"}
        obj.model_dump = MagicMock(return_value={})

        result = await bridge.render(obj, "fallback")
        assert result is None
